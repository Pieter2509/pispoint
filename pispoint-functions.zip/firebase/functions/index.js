const { onDocumentCreated, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { setGlobalOptions } = require('firebase-functions/v2');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();
const db = getFirestore();

// Moet overeenkomen met de locatie van je Firestore-database (europe-west4 = Nederland).
setGlobalOptions({ region: 'europe-west4', maxInstances: 3 });

const nameOf = async uid => {
  const d = await db.doc(`users/${uid}`).get();
  return d.exists ? (d.get('fullName') || d.get('username')) : 'Iemand';
};

// Stuur een melding naar alle apparaten van één gebruiker
async function notify(uid, pref, title, body) {
  const priv = await db.doc(`private/${uid}`).get();
  if (priv.exists && priv.get(pref) === false) return;

  const snap = await db.collection(`private/${uid}/tokens`).get();
  if (snap.empty) return;

  const messages = snap.docs.map(d => {
    const url = d.get('url');
    const webpush = { notification: {} };
    if (url) {
      webpush.notification.icon = url + 'icon-192.png';
      webpush.fcmOptions = { link: url };
    }
    return { token: d.id, notification: { title, body }, webpush };
  });

  const res = await getMessaging().sendEach(messages);

  // Verlopen of ongeldige apparaten opruimen
  await Promise.all(res.responses.map((r, i) => {
    const code = r.error && r.error.code;
    if (code === 'messaging/registration-token-not-registered' || code === 'messaging/invalid-registration-token') {
      return snap.docs[i].ref.delete();
    }
    if (r.error) console.warn('Melding mislukt', code);
    return null;
  }));
}

// Nieuw pispoint: alle vrienden van de eigenaar krijgen een melding
exports.nieuwPispoint = onDocumentCreated('pispoints/{id}', async event => {
  const p = event.data && event.data.data();
  if (!p || !p.uid) return;
  const owner = await db.doc(`users/${p.uid}`).get();
  if (!owner.exists) return;
  const name = owner.get('fullName') || owner.get('username');
  const friends = owner.get('friends') || [];
  await Promise.all(friends.map(f =>
    notify(f, 'notifyPoints', 'Nieuw pispoint 💧', `${name} heeft een nieuwe pispoint achtergelaten`)
  ));
});

// Vriendverzoek ontvangen of geaccepteerd
exports.vriendschap = onDocumentUpdated('users/{uid}', async event => {
  const before = event.data.before.data() || {};
  const after = event.data.after.data() || {};
  const uid = event.params.uid;
  const added = (a, b) => (a || []).filter(x => !(b || []).includes(x));

  const newRequests = added(after.requests, before.requests);
  const accepted = added(after.friends, before.friends).filter(x => (before.sent || []).includes(x));

  const jobs = [];
  for (const id of newRequests) {
    const n = await nameOf(id);
    jobs.push(notify(uid, 'notifyRequests', 'Vriendverzoek 👋', `${n} wil je vriend worden op Pispoint`));
  }
  for (const id of accepted) {
    const n = await nameOf(id);
    jobs.push(notify(uid, 'notifyRequests', 'Verzoek geaccepteerd 🎉', `${n} heeft je vriendverzoek geaccepteerd`));
  }
  await Promise.all(jobs);
});
